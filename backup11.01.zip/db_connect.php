<?php
require "rb-mysql.php";
//R::setup( 'mysql:host=localhost;dbname=id11959245_energyservice', 'id11959245_energyservice', '1v9m8s4t' );
R::setup( 'mysql:host=localhost;dbname=id11959245_energyservice', 'root', '' );
session_start();
?>