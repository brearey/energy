# php-upload
Application allows to upload multiple files to registered users. Registered user must be authenticated via mail. Also, user has variety of profile options, such as changing password, profile data, etc.
